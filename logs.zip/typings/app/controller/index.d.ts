// This file is created by egg-ts-helper@1.35.2
// Do not modify this file!!!!!!!!!
/* eslint-disable */

import 'egg';
import ExportBase = require('../../../app/controller/base');
import ExportExecuteSwap = require('../../../app/controller/executeSwap');
import ExportExecuteToken = require('../../../app/controller/executeToken');
import ExportHome = require('../../../app/controller/home');
import ExportPumpMonitor = require('../../../app/controller/pumpMonitor');

declare module 'egg' {
  interface IController {
    base: ExportBase;
    executeSwap: ExportExecuteSwap;
    executeToken: ExportExecuteToken;
    home: ExportHome;
    pumpMonitor: ExportPumpMonitor;
  }
}
