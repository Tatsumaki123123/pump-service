// This file is created by egg-ts-helper@1.35.2
// Do not modify this file!!!!!!!!!
/* eslint-disable */

import 'egg';
import ExportAppData = require('../../../app/model/appData');
import ExportExecuteData = require('../../../app/model/executeData');
import ExportExecuteLine = require('../../../app/model/executeLine');
import ExportExecuteToken = require('../../../app/model/executeToken');
import ExportExecuteWallet = require('../../../app/model/executeWallet');
import ExportMonitorPumpToken = require('../../../app/model/monitorPumpToken');
import ExportMonitorToken = require('../../../app/model/monitorToken');
import ExportPumpToken = require('../../../app/model/pumpToken');
import ExportReserveToken = require('../../../app/model/reserveToken');

declare module 'egg' {
  interface IModel {
    AppData: ReturnType<typeof ExportAppData>;
    ExecuteData: ReturnType<typeof ExportExecuteData>;
    ExecuteLine: ReturnType<typeof ExportExecuteLine>;
    ExecuteToken: ReturnType<typeof ExportExecuteToken>;
    ExecuteWallet: ReturnType<typeof ExportExecuteWallet>;
    MonitorPumpToken: ReturnType<typeof ExportMonitorPumpToken>;
    MonitorToken: ReturnType<typeof ExportMonitorToken>;
    PumpToken: ReturnType<typeof ExportPumpToken>;
    ReserveToken: ReturnType<typeof ExportReserveToken>;
  }
}
