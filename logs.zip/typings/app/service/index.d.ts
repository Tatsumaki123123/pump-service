// This file is created by egg-ts-helper@1.35.2
// Do not modify this file!!!!!!!!!
/* eslint-disable */

import 'egg';
type AnyClass = new (...args: any[]) => any;
type AnyFunc<T = any> = (...args: any[]) => T;
type CanExportFunc = AnyFunc<Promise<any>> | AnyFunc<IterableIterator<any>>;
type AutoInstanceType<T, U = T extends CanExportFunc ? T : T extends AnyFunc ? ReturnType<T> : T> = U extends AnyClass ? InstanceType<U> : U;
import ExportAppData = require('../../../app/service/appData');
import ExportAutoSwap = require('../../../app/service/autoSwap');
import ExportAve = require('../../../app/service/ave');
import ExportDebot = require('../../../app/service/debot');
import ExportExecuteSwap = require('../../../app/service/executeSwap');
import ExportExecuteToken = require('../../../app/service/executeToken');
import ExportGecko = require('../../../app/service/gecko');
import ExportJito = require('../../../app/service/jito');
import ExportJupAggregator = require('../../../app/service/jupAggregator');
import ExportMoralis = require('../../../app/service/moralis');
import ExportPumpAMM = require('../../../app/service/pumpAMM');
import ExportPumpAmmMonitor = require('../../../app/service/pumpAmmMonitor');
import ExportPumpfun = require('../../../app/service/pumpfun');
import ExportPumpfunMonitor = require('../../../app/service/pumpfunMonitor');

declare module 'egg' {
  interface IService {
    appData: AutoInstanceType<typeof ExportAppData>;
    autoSwap: AutoInstanceType<typeof ExportAutoSwap>;
    ave: AutoInstanceType<typeof ExportAve>;
    debot: AutoInstanceType<typeof ExportDebot>;
    executeSwap: AutoInstanceType<typeof ExportExecuteSwap>;
    executeToken: AutoInstanceType<typeof ExportExecuteToken>;
    gecko: AutoInstanceType<typeof ExportGecko>;
    jito: AutoInstanceType<typeof ExportJito>;
    jupAggregator: AutoInstanceType<typeof ExportJupAggregator>;
    moralis: AutoInstanceType<typeof ExportMoralis>;
    pumpAMM: AutoInstanceType<typeof ExportPumpAMM>;
    pumpAmmMonitor: AutoInstanceType<typeof ExportPumpAmmMonitor>;
    pumpfun: AutoInstanceType<typeof ExportPumpfun>;
    pumpfunMonitor: AutoInstanceType<typeof ExportPumpfunMonitor>;
  }
}
